jQuery(document).ready(function($) {

	// The number of the next page to load (/page/x/).
	var pageNum = parseInt(thst_alm_def.startPage) + 1;
	
	// The maximum number of pages the current query can return.
	var max = parseInt(thst_alm_def.maxPages);
	
	// The link of the next page of posts.
	var nextLink = thst_alm_def.nextLink;

	var $container_linear = $('.blog_posts .row.pcont_s, .blog_posts .row.posts_off');
	
	/**
	 * Replace the traditional navigation with our own,
	 * but only if there is at least one page of new posts to load.
	 */
	if(pageNum <= max) {
		// Insert the "More Posts" link.
		$('.blog_posts .row.posts_off, .blog_posts .row.pcont_s ')
			.append('<div class="thst-alm-placeholder-'+ pageNum +'"></div>')
			.append('<div id="thst-alm-load-posts"><a href="#">Load More Posts</a></div>');
			
		// Remove the traditional navigation.
		$('.box_pagi').remove();
	}
	
	
	/**
	 * Load new posts when the link is clicked.
	 */
	$('#thst-alm-load-posts a').click(function() {
	
		// Are there more posts to load?
		if(pageNum <= max) {
		
			// Show that we're working.
			$(this).text('Loading posts...');
			
			$('.thst-alm-placeholder-'+ pageNum).load(nextLink + ' .post',
				function() {
					// Update page number and nextLink.
					pageNum++;
					nextLink = nextLink.replace(/\/?paged=[0-9]?/, 'paged='+ pageNum);
					
					// Add a new placeholder, for when user clicks again.
					$('#thst-alm-load-posts')
						.before('<div class="thst-alm-placeholder-'+ pageNum +'"></div>')
					
					// Update the button message.
					if(pageNum <= max) {
						$('#thst-alm-load-posts a').text('Load More Posts');
					} else {
						$('#thst-alm-load-posts a').text('No more posts to load.').addClass('done');
					}

					$('.video_player').fitVids();  
					$container_linear.find('.post').fitVids();
					
					$container_linear.find('.post .flexslider').flexslider({
						animation: 'slide',
						slideshow: false,
						controlNav: false,
						slideshowSpeed: 7000,
						animationSpeed: 1000,
						touch: false,
						start: function(slider) {
							slider.removeClass('loading_post');
						}
					});
					$(".permalink_box a, .gallery-item .image_cont a, .post a:has(img)").attr("data-lightbox", "lightbox");
					
				}
			);
		} else {
			$('#thst-alm-load-posts a').append('.');
		}	
		
		return false;
	});
});